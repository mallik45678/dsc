﻿Copy-Item $PSScriptRoot\Win8.1AndW2K12R2-KB3191564-x64.msu C:\pshell\WMF5\ -Verbose 
Copy-item $PSScriptRoot\Lab_01_03_01_Install_WMF_5.ps1  C:\pshell\Labs\Lab01\ -Force -Verbose
Copy-item $PSScriptRoot\Sample_xDscWebServiceRegistration.ps1  C:\pshell\Labs\Lab03\ -Force -Verbose
Copy-item $PSScriptRoot\Lab08_01_01a_Original_Configuration.ps1  C:\pshell\Labs\Lab08\ -Force -Verbose
pause